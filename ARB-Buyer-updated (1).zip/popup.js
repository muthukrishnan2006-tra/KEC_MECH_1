const API_BASE = "https://arbbuyer.anmolpaweriya.online";

let running = false;
let lastStartTime = 0;

/* ---------------- STORAGE ---------------- */

function saveToken(token) {
  return chrome.storage.local.set({ apiToken: token });
}

function showMessage(text, screen = "main", type = "error") {
  const el = document.getElementById(screen + "-message");

  el.textContent = text;
  el.className = `message ${type}`;
  el.style.display = "block";

  // auto-hide after 10s
  setTimeout(() => {
    el.style.display = "none";
  }, 5000);
}

function getToken() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["apiToken"], (res) => {
      resolve(res.apiToken || null);
    });
  });
}

function clearToken() {
  return chrome.storage.local.remove("apiToken");
}

/* ---------------- API ---------------- */

async function verifyToken(token) {
  return {
    credits: 1000
  };
}
async function useCredits(amount = 1) {
    return true;
}

/* ---------------- UI ---------------- */

function showMainScreen(credits) {
  document.getElementById("authScreen").style.display = "none";
  document.getElementById("mainScreen").style.display = "block";

  document.getElementById("credits").textContent = credits;
}

function showAuthScreen() {
  document.getElementById("authScreen").style.display = "block";
  document.getElementById("mainScreen").style.display = "none";
}

function updateUI(status) {
  if (!status) return;

  running = status.running;

  const statusEl = document.getElementById("status");
  statusEl.textContent = running ? "Running" : "Stopped";
  statusEl.className = running ? "running" : "stopped";

  const btn = document.getElementById("toggle");
  btn.textContent = running ? "Stop" : "Start";
  btn.className = running ? "stop" : "start";
}

/* ---------------- CONTENT SCRIPT ---------------- */

function send(action, callback) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tabId = tabs[0].id;

    chrome.tabs.sendMessage(tabId, action, (response) => {
      if (chrome.runtime.lastError) {
        chrome.scripting.executeScript(
          {
            target: { tabId },
            files: ["content.js"],
          },
          () => chrome.tabs.sendMessage(tabId, action, callback),
        );
        return;
      }

      callback?.(response);
    });
  });
}

function refreshStatus() {
  send({ action: "status" }, updateUI);
}

/* ---------------- EVENTS ---------------- */

document.getElementById("loginBtn").addEventListener("click", async () => {
  const token = document.getElementById("tokenInput").value.trim();

  const data = await verifyToken(token);

  if (!data) {
    showMessage("Invalid token", "auth");
    return;
  }

  await saveToken(token);
  showMainScreen(data.credits);
});

document.getElementById("logout").addEventListener("click", async () => {
  await clearToken();
  showAuthScreen();
});

document.getElementById("toggle").addEventListener("click", async () => {
  const now = Date.now();

  if (!running && now - lastStartTime < 3000) {
    showMessage("Please wait before restarting");
    return;
  }

  if (!running) {
    const allowed = await useCredits(1);

    if (!allowed) {
      showMessage("No credits left");
      return;
    }

    lastStartTime = now;

    const creditsEl = document.getElementById("credits");
    creditsEl.textContent = Number(creditsEl.textContent) - 1;
  }

  send(
    {
      action: running ? "stop" : "start",
      min: Number(document.getElementById("min").value),
      max: Number(document.getElementById("max").value),
      delay: Number(document.getElementById("delay").value),
      reloadType: document.getElementById("reloadType").value,
    },
    refreshStatus,
  );
});

document.getElementById("open-arb").addEventListener("click", () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.update(tabs[0].id, {
      url: "https://arbpay.me/#/buy/arb",
    });
  });
});

/* ---------------- INIT ---------------- */

document.addEventListener("DOMContentLoaded", async () => {
  const token = await getToken();

  if (!token) {
    showAuthScreen();
    return;
  }

  const data = await verifyToken(token);

  if (!data) {
    showAuthScreen();
    return;
  }

  showMainScreen(data.credits);
  refreshStatus();
});
