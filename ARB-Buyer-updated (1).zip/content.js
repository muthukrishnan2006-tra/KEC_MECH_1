let arbInterval = null;
let buyCount = 0;
let observer = null;

function stopInterval(reason = "") {
  if (arbInterval) {
    clearInterval(arbInterval);
    arbInterval = null;
    console.log("Auto-buy stopped:", reason);
  }

  if (observer) {
    observer.disconnect();
    observer = null;
  }
}

function startObserver() {
  observer = new MutationObserver(() => {
    const list = document.querySelector(".x-buyList-list");
    if (!list || list.children.length === 0) {
      stopInterval("Order list removed (buy success)");
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });
}

function buyBestOrder(max, min, delay, reloadType) {
  stopInterval("restart");

  if (!document.querySelector(".x-buyList-list")) {
    console.warn("Buy list not found");
    return;
  }

  startObserver();

  // The site's old OTP/BANK tab-based "reload" mechanism was replaced with a
  // Default/Large/Small popover filter above the order list. Selecting one of
  // these options also refreshes the visible orders, so we reuse it as the
  // reload action.
  function clickFilterOption(optionText) {
    const trigger = document.querySelector(
      ".x-buyList-filter .van-popover__wrapper button",
    );

    if (!trigger) {
      console.warn("Filter trigger button not found");
      return;
    }

    const isAlreadyOpen = !!document.querySelector(
      ".van-popover__content .van-popover__action",
    );

    if (!isAlreadyOpen) {
      trigger.click();
    }

    // The popover content is appended to the DOM asynchronously after the
    // trigger is clicked, so give it a brief moment before querying it.
    setTimeout(
      () => {
        const options = document.querySelectorAll(
          ".van-popover__action .van-popover__action-text",
        );

        const target = Array.from(options).find(
          (el) => el.textContent.trim() === optionText,
        );

        if (target) {
          target.closest(".van-popover__action")?.click();
        } else {
          console.warn(`Filter option "${optionText}" not found`);
        }
      },
      isAlreadyOpen ? 0 : 80,
    );
  }

  arbInterval = setInterval(() => {
    const list = document.querySelector(".x-buyList-list");

    if (!list) {
      stopInterval("List disappeared");
      return;
    }

    document.querySelectorAll(".x-buyList-list .item").forEach((val) => {
      // The site now exposes the order's max buy amount directly as an
      // attribute on the item container instead of via text content.
      const rawAmount = val.getAttribute("maximumamount");
      if (rawAmount === null) return;

      const amount = Number(rawAmount);
      if (Number.isNaN(amount)) return;

      if (amount <= max && amount >= min) {
        const btn = val.querySelector("button");
        if (btn) {
          btn.click();
          buyCount++;
        }
      }
    });

    if (reloadType !== "NONE") {
      clickFilterOption(reloadType);
    }
  }, delay);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "start") {
    buyBestOrder(msg.max, msg.min, msg.delay, msg.reloadType);
    sendResponse({ running: true, buyCount });
  }

  if (msg.action === "stop") {
    stopInterval("manual");
    sendResponse({ running: false, buyCount });
  }

  if (msg.action === "status") {
    sendResponse({
      running: !!arbInterval,
      buyCount,
    });
  }

  return true;
});
